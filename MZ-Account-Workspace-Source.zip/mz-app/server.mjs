import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import A from './core.cjs';
import {encryptedBackup} from './store.mjs';
import {openAsyncStore,mutex} from './async-store.mjs';
import {random,sha,safeEqual,passwordHash,verifyPassword,base32,totpStep} from './security.mjs';

const here=path.dirname(fileURLToPath(import.meta.url));
const fail=(status,message)=>{throw Object.assign(Error(message),{status});};
const text=(v,max=150)=>{if(typeof v!=='string'||!v.trim()||v.length>max||/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(v))fail(400,'Invalid text field.');return v.trim();};
const email=v=>{const s=text(v,254).toLowerCase();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s))fail(400,'Enter a valid email.');return s;};
const today=()=>new Date().toISOString().slice(0,10);
const publicFiles=new Set(fs.readdirSync(path.join(here,'public')).filter(x=>/\.(html|css|js|svg|txt|xml)$/.test(x)));

export async function createApp(config={}) {
  const cfg={production:process.env.NODE_ENV==='production',origin:process.env.APP_ORIGIN||'http://127.0.0.1:8770',dbFile:process.env.DB_FILE,databaseUrl:process.env.DATABASE_URL,
    key:process.env.DATA_KEY,backupKey:process.env.BACKUP_KEY,backupDir:process.env.BACKUP_DIR,mailKey:process.env.RESEND_API_KEY,
    remoteBackupsVerified:process.env.REMOTE_BACKUPS_CONFIRMED==='yes',mailFrom:process.env.MAIL_FROM,durable:process.env.DURABLE_STORAGE_CONFIRMED==='yes',mailMode:process.env.MAIL_MODE||'outbox',outbox:process.env.DEV_OUTBOX,
    ...config};
  const origin=new URL(cfg.origin);if(origin.origin!==cfg.origin)throw Error('APP_ORIGIN must be an exact origin without path or trailing slash.');
  if((!cfg.dbFile&&!cfg.databaseUrl)||!cfg.key)throw Error('DB_FILE and DATA_KEY are required.');
  if(cfg.production) {
    if(origin.protocol!=='https:'||!cfg.durable||cfg.mailMode!=='resend'||!cfg.mailKey||!cfg.mailFrom||!cfg.backupDir||!cfg.backupKey)throw Error('Production is locked: configure HTTPS, durable database, verified email and encrypted backups.');
    if(cfg.databaseUrl&&!cfg.remoteBackupsVerified)throw Error('Verify external PostgreSQL backup and restore before production.');
    if(cfg.key===cfg.backupKey)throw Error('Use a separate backup encryption key.');
  } else if(!['127.0.0.1','localhost'].includes(origin.hostname))throw Error('Development must use a loopback origin.');
  const store=await openAsyncStore(cfg),{run,one,all,crypt,put,get,list,audit,transaction}=store;
  const dummy=await passwordHash(random());
  const cookieName=cfg.production?'__Host-mz_session':'mz_dev_session';
  const cookie=(token,seconds=28800)=>`${cookieName}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${seconds}${cfg.production?'; Secure':''}`;
  let mailBusy=false;
  async function queueMail(uid,to,subject,body) {
    const id=crypto.randomUUID();(await run('INSERT INTO mail(id,user_id,payload,created) VALUES(?,?,?,?)',id,uid,crypt.seal({to,subject,text:body},'mail:'+id),Date.now()));
  }
  async function drainMail() {
    if(mailBusy)return;mailBusy=true;
    try {for(const row of (await all('SELECT * FROM mail WHERE next<=? ORDER BY created LIMIT 10',Date.now()))) {
      const value=crypt.open(row.payload,'mail:'+row.id);
      try {
        if(cfg.mailMode==='resend') {
          const r=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${cfg.mailKey}`,'Content-Type':'application/json','Idempotency-Key':row.id},body:JSON.stringify({from:cfg.mailFrom,to:[value.to],subject:value.subject,text:value.text}),signal:AbortSignal.timeout(10000)});
          if(!r.ok)throw Error('Mail provider rejected delivery');
        } else {
          if(cfg.production||!cfg.outbox)throw Error('Development outbox not configured');
          fs.mkdirSync(cfg.outbox,{recursive:true});fs.writeFileSync(path.join(cfg.outbox,row.id+'.json'),JSON.stringify(value),{mode:0o600});
        }
        (await run('DELETE FROM mail WHERE id=?',row.id));
      } catch {(await run('UPDATE mail SET attempts=attempts+1,next=? WHERE id=?',Date.now()+Math.min(3600000,30000*2**Math.min(row.attempts,7)),row.id));}
    }} finally{mailBusy=false;}
  }
  async function limit(key,count,window=900000) {
    const hashed=crypt.index('limit:'+key),now=Date.now();
    (await run('INSERT INTO limits VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN limits.until<? THEN 1 ELSE limits.count+1 END,until=CASE WHEN limits.until<? THEN excluded.until ELSE limits.until END',hashed,now+window,now,now));
    if((await one('SELECT count FROM limits WHERE key=?',hashed)).count>count)fail(429,'Too many requests. Please try again later.');
  }
  function userProfile(u){return crypt.open(u.profile,'profile:'+u.id);}
  async function newToken(uid,kind) {
    const token=random();(await run('DELETE FROM tokens WHERE user_id=? AND kind=?',uid,kind));(await run('INSERT INTO tokens VALUES(?,?,?,?)',sha(token),uid,kind,Date.now()+(kind==='verify'?86400000:1800000)));return token;
  }
  async function factor(u,code) {
    if(!u.mfa)return true;
    const m=crypt.open(u.mfa,'mfa:'+u.id),step=totpStep(m.secret,code,m.last??-1);
    if(step!==null)m.last=step;
    else {const h=sha(String(code||'')),i=m.recovery.indexOf(h);if(i<0)return false;m.recovery.splice(i,1);}
    (await run('UPDATE users SET mfa=? WHERE id=?',crypt.seal(m,'mfa:'+u.id),u.id));return true;
  }
  async function reauth(u,b) {
    (await limit('reauth:'+u.id,10));
    if(!await verifyPassword(b.password,u.password)||!(await factor(u,b.code)))fail(401,'Password or second factor was not accepted.');
  }
  async function session(req,full=true) {
    const raw=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith(cookieName+'='))?.slice(cookieName.length+1)||'';
    const s=(await one('SELECT * FROM sessions WHERE hash=?',sha(raw)));
    if(!s||s.expires<Date.now()||s.seen<Date.now()-1800000)fail(401,'Please sign in again.');
    const u=(await one('SELECT * FROM users WHERE id=?',s.user_id));if(!u||!u.verified)fail(401,'Please sign in again.');
    if(full&&s.scope!=='full')fail(403,'Complete two-step verification.');
    if(!req.url.startsWith('/api/events')&&!req.url.startsWith('/api/support'))(await run('UPDATE sessions SET seen=? WHERE hash=?',Date.now(),s.hash));
    if(req.method!=='GET'&&!safeEqual(req.headers['x-csrf-token']||'',s.csrf))fail(403,'Refresh the page and retry.');
    return {s,u};
  }
  async function makeSession(uid,scope,res) {
    const token=random(),csrf=random(),now=Date.now();
    (await run('INSERT INTO sessions VALUES(?,?,?,?,?,?,?)',sha(token),uid,csrf,scope,now+(scope==='full'?28800000:300000),now,now));
    res.setHeader('Set-Cookie',cookie(token,scope==='full'?28800:300));return {csrf,needsMfa:scope!=='full'};
  }
  async function invoice(uid,id){const v=(await get(uid,text(id,80),'invoice'));if(!v)fail(404,'Invoice not found.');return v;}
  function clean(v){const {log,approved,draft,...rest}=v;return rest;}
  function requireRevision(v,b){if(b.revision!==v.revision)fail(409,'This invoice changed. Reload before saving.');}
  function invoiceRules(v){const csv=A.columns.map(k=>'"'+String(k==='amount'||k==='paid'?v[k]/100:v[k]??'').replaceAll('"','""')+'"').join(',');try{return clean(A.validate(A.columns.join(',')+'\n'+csv)[0]);}catch(e){fail(400,e.message);}}
  async function body(req) {
    if(!req.headers['content-type']?.startsWith('application/json'))fail(415,'JSON content is required.');
    let chunks=[],n=0;for await(const c of req){n+=c.length;if(n>1100000)fail(413,'Request is too large.');chunks.push(c);}
    try{const b=JSON.parse(Buffer.concat(chunks).toString());if(!b||Array.isArray(b)||typeof b!=='object')throw Error();return b;}catch{fail(400,'Invalid JSON.');}
  }
  function headers(res) {
    res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');res.setHeader('Referrer-Policy','no-referrer');
    res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=(), payment=()');
    res.setHeader('Cross-Origin-Opener-Policy','same-origin');res.setHeader('Cross-Origin-Resource-Policy','same-origin');
    res.setHeader('Content-Security-Policy',"default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; font-src 'self'; frame-ancestors 'none'; form-action 'self'; base-uri 'none'; object-src 'none'");
    if(cfg.production)res.setHeader('Strict-Transport-Security','max-age=31536000');
    res.setHeader('Cache-Control','no-store');
  }
  function json(res,status,data){res.statusCode=status;res.setHeader('Content-Type','application/json; charset=utf-8');res.end(JSON.stringify(data));}
  const requestQueue=mutex(30);
  const server=http.createServer((req,res)=>requestQueue(async()=>{
    headers(res);
    try {
      const url=new URL(req.url,cfg.origin),p=url.pathname;
      if(!['GET','POST'].includes(req.method))fail(405,'Method not supported.');
      if(req.method==='POST'&&req.headers.origin!==cfg.origin)fail(403,'Request origin was not accepted.');
      if(p==='/healthz')return json(res,200,{status:'ok'});
      if(!p.startsWith('/api/')) {
        if(req.method!=='GET')fail(405,'Method not supported.');
        const file=p==='/'?'index.html':p==='/workspace'?'workspace.html':p.slice(1);
        if(!publicFiles.has(file))fail(404,'Page not found.');
        const ext=path.extname(file),mime={'.html':'text/html','.css':'text/css','.js':'text/javascript','.svg':'image/svg+xml','.txt':'text/plain','.xml':'application/xml'}[ext];
        let content=fs.readFileSync(path.join(here,'public',file),'utf8').replaceAll('__SITE_ORIGIN__',cfg.origin);
        if(ext==='.html') {
          const schema=content.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)?.[1];
          if(schema)res.setHeader('Content-Security-Policy',res.getHeader('Content-Security-Policy').replace("script-src 'self'",`script-src 'self' 'sha256-${crypto.createHash('sha256').update(schema).digest('base64')}'`));
        }
        if(file==='workspace.html')res.setHeader('X-Robots-Tag','noindex, nofollow');
        res.setHeader('Content-Type',mime+'; charset=utf-8');return res.end(content);
      }
      (await limit('ip:'+req.socket.remoteAddress,500,60000));
      const b=req.method==='POST'?await body(req):{};
      if(p==='/api/status')return json(res,200,{mode:cfg.production?'production':'local-test',email:cfg.mailMode==='resend'?'provider-configured':'local-outbox',payments:false,ai:false});
      if(p==='/api/leads'&&req.method==='POST') {
        (await limit('lead:'+req.socket.remoteAddress,5,3600000));if(b.website)return json(res,202,{ok:true});
        if(b.consent!==true)fail(400,'Please agree to a response about this inquiry.');
        const value={name:text(b.name,100),email:email(b.email),message:text(b.message,2000),created:Date.now(),consent:'inquiry-response-only'};
        const id=crypto.randomUUID();(await run('INSERT INTO leads VALUES(?,?,?)',id,crypt.seal(value,'lead:'+id),Date.now()));return json(res,201,{ok:true});
      }
      if(p==='/api/register'&&req.method==='POST') {
        (await limit('signup:'+req.socket.remoteAddress,8,3600000));const address=email(b.email),idx=crypt.index('email:'+address);
        (await limit('signup:'+idx,3,3600000));const hash=await passwordHash(b.password),name=text(b.name,100);
        if(b.terms!==true)fail(400,'Please read and accept the workspace terms.');
        if(!(await one('SELECT id FROM users WHERE email_index=?',idx)))(await transaction(async()=>{
          const id=crypto.randomUUID();(await run('INSERT INTO users(id,email_index,password,profile,created) VALUES(?,?,?,?,?)',id,idx,hash,crypt.seal({name,email:address,termsAcceptedAt:Date.now()},'profile:'+id),Date.now()));
          const token=(await newToken(id,'verify'));(await queueMail(id,address,'Verify your MZ Consultancy email',`Open ${cfg.origin}/workspace#verify=${token}\nThis verification expires in 24 hours.`));(await audit(id,'account.created'));
        }));
        await drainMail();return json(res,202,{message:'If registration is available for this address, verification instructions will arrive by email.'});
      }
      if(p==='/api/verify'&&req.method==='POST') {
        const t=(await one('SELECT * FROM tokens WHERE hash=? AND kind=? AND expires>?',sha(text(b.token,100)),'verify',Date.now()));if(!t)fail(400,'Verification link expired or already used.');
        (await transaction(async()=>{(await run('UPDATE users SET verified=1 WHERE id=?',t.user_id));(await run('DELETE FROM tokens WHERE hash=?',t.hash));(await audit(t.user_id,'email.verified'));}));return json(res,200,{message:'Email verified. You can now sign in.'});
      }
      if(['/api/forgot','/api/resend-verification'].includes(p)&&req.method==='POST') {
        (await limit('recovery-ip:'+req.socket.remoteAddress,15,3600000));const address=email(b.email),idx=crypt.index('email:'+address);(await limit('recovery:'+idx,3,3600000));
        const u=(await one('SELECT * FROM users WHERE email_index=?',idx)),kind=p==='/api/forgot'?'reset':'verify';
        if(u&&(kind==='reset'?u.verified:!u.verified)){const token=(await newToken(u.id,kind));(await queueMail(u.id,address,'MZ Consultancy account request',`Open ${cfg.origin}/workspace#${kind}=${token}\nIf you did not request this, ignore this message.`));await drainMail();}
        return json(res,202,{message:'If the address is eligible, instructions will arrive by email.'});
      }
      if(p==='/api/reset'&&req.method==='POST') {
        (await limit('reset:'+req.socket.remoteAddress,10));const hash=await passwordHash(b.password);
        const t=(await one('SELECT * FROM tokens WHERE hash=? AND kind=? AND expires>?',sha(text(b.token,100)),'reset',Date.now()));if(!t)fail(400,'Reset link expired or already used.');
        (await transaction(async()=>{(await run('UPDATE users SET password=? WHERE id=?',hash,t.user_id));(await run('DELETE FROM sessions WHERE user_id=?',t.user_id));(await run('DELETE FROM tokens WHERE user_id=?',t.user_id));(await audit(t.user_id,'password.reset'));}));
        const u=(await one('SELECT * FROM users WHERE id=?',t.user_id));(await queueMail(u.id,userProfile(u).email,'Your MZ password changed','Your password was reset and existing sessions were signed out. Two-step verification remains enabled if previously configured. Contact support if this was not you.'));
        return json(res,200,{message:'Password reset. Existing sessions were revoked. Sign in again.'});
      }
      if(p==='/api/login'&&req.method==='POST') {
        (await limit('login-ip:'+req.socket.remoteAddress,30));const idx=crypt.index('email:'+email(b.email));(await limit('login:'+idx,10));
        const u=(await one('SELECT * FROM users WHERE email_index=?',idx));
        const valid=await verifyPassword(b.password,u?.password||dummy);
        if(!valid||!u?.verified||(await one('SELECT password FROM users WHERE id=?',u.id))?.password!==u.password)fail(401,'Sign-in failed. Check your credentials and verify your email.');
        const result=(await makeSession(u.id,u.mfa?'mfa':'full',res));(await audit(u.id,'login.password-accepted'));
        if(!u.mfa)(await queueMail(u.id,userProfile(u).email,'New MZ Consultancy sign-in','A new sign-in occurred. If it was not you, reset your password to revoke all sessions.'));
        return json(res,200,result);
      }
      if(p==='/api/mfa/login'&&req.method==='POST') {
        const {s,u}=(await session(req,false));(await limit('mfa:'+u.id,8));if(s.scope!=='mfa'||!(await factor(u,b.code)))fail(401,'Second factor was not accepted.');
        (await run('DELETE FROM sessions WHERE hash=?',s.hash));const result=(await makeSession(u.id,'full',res));(await audit(u.id,'login.mfa-accepted'));
        (await queueMail(u.id,userProfile(u).email,'New MZ Consultancy sign-in','A new sign-in passed two-step verification. If it was not you, revoke sessions and contact support.'));return json(res,200,result);
      }
      const {s,u}=(await session(req));(await limit('user:'+u.id,180,60000));
      if(p==='/api/me'&&req.method==='GET')return json(res,200,{...userProfile(u),id:u.id,csrf:s.csrf,mfa:!!u.mfa,role:'owner',onboardingRequired:cfg.production&&!u.mfa});
      if(p==='/api/logout'&&req.method==='POST'){(await run('DELETE FROM sessions WHERE hash=?',s.hash));res.setHeader('Set-Cookie',cookie('',0));return json(res,200,{ok:true});}
      if(p==='/api/sessions'&&req.method==='GET')return json(res,200,{sessions:(await all('SELECT created,seen,expires FROM sessions WHERE user_id=?',u.id))});
      if(p==='/api/sessions/revoke'&&req.method==='POST'){await reauth(u,b);(await run('DELETE FROM sessions WHERE user_id=?',u.id));res.setHeader('Set-Cookie',cookie('',0));(await audit(u.id,'sessions.revoked'));return json(res,200,{ok:true});}
      if(p==='/api/profile'&&req.method==='POST'){const profile=userProfile(u);profile.name=text(b.name,100);(await run('UPDATE users SET profile=? WHERE id=?',crypt.seal(profile,'profile:'+u.id),u.id));(await audit(u.id,'profile.updated'));return json(res,200,{ok:true});}
      if(p==='/api/mfa/setup'&&req.method==='POST') {
        await reauth(u,b);if(u.mfa)fail(409,'Two-step verification is already enabled.');
        const secret=base32(crypto.randomBytes(20));(await put(u.id,'pending','mfa',{secret,expires:Date.now()+600000}));
        return json(res,200,{secret,uri:`otpauth://totp/MZ%20Consultancy:${encodeURIComponent(userProfile(u).email)}?secret=${secret}&issuer=MZ%20Consultancy&algorithm=SHA1&digits=6&period=30`});
      }
      if(p==='/api/mfa/enable'&&req.method==='POST') {
        (await limit('mfa:'+u.id,8));const pending=(await get(u.id,'pending','mfa'));if(u.mfa||!pending||pending.expires<Date.now())fail(400,'Start setup again.');
        const step=totpStep(pending.secret,b.code);if(step===null)fail(400,'Authenticator code was not accepted.');
        const recovery=Array.from({length:8},()=>crypto.randomBytes(12).toString('hex'));
        (await transaction(async()=>{(await run('UPDATE users SET mfa=? WHERE id=?',crypt.seal({secret:pending.secret,last:step,recovery:recovery.map(sha)},'mfa:'+u.id),u.id));(await run('DELETE FROM records WHERE user_id=? AND kind=?',u.id,'mfa'));(await run('DELETE FROM sessions WHERE user_id=? AND hash<>?',u.id,s.hash));(await audit(u.id,'mfa.enabled'));}));
        return json(res,200,{recovery,message:'Save these recovery codes offline. Each can be used once.'});
      }
      if(p==='/api/export'&&req.method==='POST') {
        await reauth(u,b);(await audit(u.id,'data.exported'));return json(res,200,{profile:userProfile(u),invoices:(await list(u.id,'invoice')),drafts:(await list(u.id,'draft')),support:(await list(u.id,'support')),feedback:(await list(u.id,'feedback')),events:(await all('SELECT kind,created FROM events WHERE user_id=?',u.id))});
      }
      if(p==='/api/delete-account'&&req.method==='POST') {
        await reauth(u,b);if(b.confirmation!=='DELETE MY ACCOUNT')fail(400,'Type DELETE MY ACCOUNT to confirm.');
        (await run('DELETE FROM users WHERE id=?',u.id));res.setHeader('Set-Cookie',cookie('',0));return json(res,200,{message:'Active account data deleted. Encrypted backups expire under the retention policy.'});
      }
      if(p==='/api/events'&&req.method==='GET')return json(res,200,{events:(await all('SELECT kind,created FROM events WHERE user_id=? ORDER BY id DESC LIMIT 50',u.id))});
      if(p==='/api/support'&&req.method==='POST') {
        (await limit('support:'+u.id,10,86400000));const id=crypto.randomUUID();(await put(u.id,id,'support',{id,subject:text(b.subject,150),message:text(b.message,3000),status:'received',created:Date.now()}));(await audit(u.id,'support.received'));return json(res,201,{id});
      }
      if(p==='/api/support'&&req.method==='GET')return json(res,200,{tickets:(await list(u.id,'support'))});
      if(p==='/api/feedback'&&req.method==='POST'){(await limit('feedback:'+u.id,3,86400000));if(!Number.isInteger(b.rating)||b.rating<1||b.rating>5)fail(400,'Choose 1–5.');const id=crypto.randomUUID();(await put(u.id,id,'feedback',{id,rating:b.rating,message:text(b.message,1500),created:Date.now()}));return json(res,201,{ok:true});}
      if(p==='/api/billing'&&req.method==='GET')return json(res,200,{enabled:false,transactions:[],message:'No online charges or subscriptions. Service payment terms are agreed separately.'});
      if(cfg.production&&!u.mfa)fail(403,'Enable two-step verification before adding invoice data.');
      if(p==='/api/invoices'&&req.method==='GET') {
        const q=(url.searchParams.get('q')||'').slice(0,150).toLowerCase(),filter=url.searchParams.get('status')||'';
        const rows=(await list(u.id,'invoice')).map(v=>({...v,balance:A.balance(v),state:A.state(v,today()),eligible:A.eligible(v,today())}));
        return json(res,200,{asOf:today(),invoices:rows.filter(v=>(v.company+' '+v.id).toLowerCase().includes(q)&&(!filter||v.status===filter)),totals:{outstanding:rows.reduce((s,v)=>s+v.balance,0),overdue:rows.filter(v=>A.age(v,today())>0).reduce((s,v)=>s+v.balance,0),eligible:rows.filter(v=>v.eligible).length}});
      }
      if(p==='/api/import/preview'&&req.method==='POST') {
        if(typeof b.csv!=='string'||Buffer.byteLength(b.csv)>1000000)fail(400,'Use a CSV under 1 MB.');
        let rows;try{rows=A.validate(b.csv).map(clean);}catch(e){fail(400,e.message);}
        const current=(await list(u.id,'invoice')),hash=sha(JSON.stringify(current));
        if(current.length+rows.filter(v=>!current.some(c=>c.id===v.id)).length>500)fail(400,'Maximum 500 stored invoices.');
        (await put(u.id,'pending','import',{rows,base:hash,token:random(),expires:Date.now()+600000}));const pending=(await get(u.id,'pending','import'));
        return json(res,200,{count:rows.length,updates:rows.filter(v=>current.some(c=>c.id===v.id)).length,token:pending.token,rows});
      }
      if(p==='/api/import/commit'&&req.method==='POST') {
        const pending=(await get(u.id,'pending','import'));if(!pending||pending.expires<Date.now()||!safeEqual(b.token||'',pending.token))fail(400,'Preview expired. Preview the CSV again.');
        if(pending.base!==sha(JSON.stringify((await list(u.id,'invoice')))))fail(409,'Invoices changed after preview. Preview again.');
        (await transaction(async()=>{for(const row of pending.rows){const old=(await get(u.id,row.id,'invoice'));(await put(u.id,row.id,'invoice',row,(old?.revision||0)+1));(await run('DELETE FROM records WHERE user_id=? AND id=? AND kind=?',u.id,row.id,'draft'));}(await run('DELETE FROM records WHERE user_id=? AND kind=?',u.id,'import'));(await audit(u.id,'invoices.imported'));}));return json(res,200,{count:pending.rows.length});
      }
      if(p==='/api/invoice/update'&&req.method==='POST') {
        const v=(await invoice(u.id,b.id));requireRevision(v,b);let paid;try{paid=A.cents(b.paid);}catch(e){fail(400,e.message);}
        const next=invoiceRules({...v,paid,status:b.status,promise:b.promise||''});
        (await transaction(async()=>{(await put(u.id,v.id,'invoice',next,v.revision+1));(await run('DELETE FROM records WHERE user_id=? AND id=? AND kind=?',u.id,v.id,'draft'));(await audit(u.id,'invoice.updated'));}));return json(res,200,{ok:true});
      }
      if(p==='/api/draft/create'&&req.method==='POST') {
        const v=(await invoice(u.id,b.id));requireRevision(v,b);if(!A.eligible(v,today()))fail(409,'This invoice is on hold.');
        const value={id:v.id,invoiceRevision:v.revision,body:A.draft(v,today()),approved:false,asOf:today()};(await put(u.id,v.id,'draft',value));(await audit(u.id,'draft.created'));return json(res,200,value);
      }
      if(p==='/api/draft/approve'&&req.method==='POST') {
        const v=(await invoice(u.id,b.id)),d=(await get(u.id,v.id,'draft'));requireRevision(v,b);if(!d||d.invoiceRevision!==v.revision||!A.eligible(v,today())||d.asOf!==today())fail(409,'Draft is no longer current. Generate it again.');
        const value={...d,body:text(b.body,8000),approved:true,approvedAt:Date.now()};value.hash=sha(value.body);(await put(u.id,v.id,'draft',value));(await audit(u.id,'draft.approved'));return json(res,200,{ok:true});
      }
      if(p==='/api/draft/download'&&req.method==='POST') {
        const v=(await invoice(u.id,b.id)),d=(await get(u.id,v.id,'draft'));if(!d?.approved||d.invoiceRevision!==v.revision||d.asOf!==today()||!A.eligible(v,today())||d.hash!==sha(d.body))fail(409,'Approve a current eligible draft first.');
        (await audit(u.id,'draft.downloaded'));return json(res,200,{body:d.body});
      }
      if(p==='/api/report'&&req.method==='GET') {
        const rows=(await list(u.id,'invoice'));return json(res,200,{csv:A.csv([['Invoice','Company','Balance USD','Due','Status','Promise','Next action'],...rows.map(v=>[v.id,v.company,(A.balance(v)/100).toFixed(2),v.due,v.status,v.promise,A.state(v,today())])]),generated:today(),method:'Verified invoice fields and deterministic rules; not AI-generated.'});
      }
      fail(404,'Endpoint not found.');
    } catch(e) {if(!res.headersSent){if(e.status===429)res.setHeader('Retry-After','900');json(res,e.status||500,{error:e.status?e.message:'Request could not be completed. Please retry.'});}else res.end();}
  }).catch(()=>{headers(res);json(res,503,{error:'Service is busy. Please retry shortly.'});}));
  server.requestTimeout=15000;server.headersTimeout=10000;server.maxHeadersCount=50;
  const mailTimer=setInterval(()=>drainMail().catch(()=>{}),30000);mailTimer.unref();
  let backupBusy=false;
  async function backupNow(){if(store.kind!=='sqlite'||!cfg.backupDir||!cfg.backupKey||backupBusy)return;backupBusy=true;try{await encryptedBackup(store,path.join(cfg.backupDir,`mz-${Date.now()}.enc`),cfg.backupKey);const cutoff=Date.now()-30*86400000;for(const f of fs.readdirSync(cfg.backupDir)){const m=/^mz-(\d+)\.enc$/.exec(f);if(m&&Number(m[1])<cutoff)fs.unlinkSync(path.join(cfg.backupDir,f));}}finally{backupBusy=false;}}
  async function cleanupRecords(){const now=Date.now();(await run('DELETE FROM sessions WHERE expires<? OR seen<?',now,now-1800000));(await run('DELETE FROM tokens WHERE expires<?',now));(await run('DELETE FROM limits WHERE until<?',now));(await run('DELETE FROM leads WHERE created<?',now-90*86400000));(await run('DELETE FROM events WHERE created<?',now-90*86400000));}
  const cleanup=setInterval(()=>cleanupRecords().catch(()=>console.error('Retention cleanup failed; operator action required.')),3600000);cleanup.unref();
  const backupTimer=setInterval(()=>backupNow().catch(()=>{console.error('Encrypted backup failed; operator action required.');}),86400000);backupTimer.unref();
  return {server,store,cfg,drainMail,backupNow,async close(){clearInterval(mailTimer);clearInterval(cleanup);clearInterval(backupTimer);await new Promise(resolve=>server.close(resolve));await store.close();}};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  const app=await createApp();const port=Number(process.env.PORT||8770);
  app.server.listen(port,app.cfg.production?'0.0.0.0':'127.0.0.1',()=>console.log(`MZ workspace listening on port ${port}. ${app.cfg.production?'Production configuration loaded.':'Local test mode; use fictional data only.'}`));
  if(app.cfg.production)await app.backupNow();
}
