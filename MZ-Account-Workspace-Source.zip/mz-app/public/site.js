const button=document.getElementById('theme-toggle');
let theme;try{theme=localStorage.getItem('mz-theme')}catch{}
if(!['dark','light'].includes(theme))theme=matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';
function apply(){document.documentElement.dataset.theme=theme;if(button){button.textContent=theme==='dark'?'Light mode':'Dark mode';button.setAttribute('aria-label','Switch to '+(theme==='dark'?'light':'dark')+' mode')}}
apply();button?.addEventListener('click',()=>{theme=theme==='dark'?'light':'dark';apply();try{localStorage.setItem('mz-theme',theme)}catch{}});
