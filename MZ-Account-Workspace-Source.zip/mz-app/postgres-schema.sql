-- Applied to MZ CONSULTANCY / neondb on 9 October 2026. App connection still unverified.
-- Run via a private migration role. Runtime should use a separate restricted role.
-- Never expose database credentials to the browser. Public browser clients have no SQL access.
BEGIN;
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email_index TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  profile TEXT NOT NULL,
  verified INTEGER NOT NULL DEFAULT 0 CHECK(verified IN (0,1)),
  mfa TEXT,
  created BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  csrf TEXT NOT NULL, scope TEXT NOT NULL CHECK(scope IN ('mfa','full')),
  expires BIGINT NOT NULL, seen BIGINT NOT NULL, created BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS sessions_owner ON sessions(user_id);
CREATE INDEX IF NOT EXISTS sessions_expiry ON sessions(expires);
CREATE TABLE IF NOT EXISTS tokens (
  hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK(kind IN ('verify','reset')), expires BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS tokens_owner ON tokens(user_id,kind);
CREATE TABLE IF NOT EXISTS records (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL,kind TEXT NOT NULL,payload TEXT NOT NULL,
  revision INTEGER NOT NULL DEFAULT 1 CHECK(revision>0),PRIMARY KEY(user_id,id,kind)
);
CREATE INDEX IF NOT EXISTS records_owner_kind ON records(user_id,kind);
CREATE TABLE IF NOT EXISTS events (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,created BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS events_owner ON events(user_id,id DESC);
CREATE TABLE IF NOT EXISTS limits (key TEXT PRIMARY KEY,count INTEGER NOT NULL,until BIGINT NOT NULL);
CREATE TABLE IF NOT EXISTS mail (
  id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  payload TEXT NOT NULL,created BIGINT NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,next BIGINT NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS leads(id TEXT PRIMARY KEY,payload TEXT NOT NULL,created BIGINT NOT NULL);
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
COMMIT;
