import {openStore,encryptedBackup,restoreBackup} from '../store.mjs';
import {DatabaseSync} from 'node:sqlite';
import path from 'node:path';
const {DB_FILE,DATA_KEY,BACKUP_KEY,BACKUP_DIR}=process.env;
if(process.argv[2]==='restore'){
  if(!process.argv[3]||!process.argv[4])throw Error('Usage: backup.mjs restore BACKUP_FILE NEW_DATABASE_FILE');
  restoreBackup(process.argv[3],process.argv[4],BACKUP_KEY);
  const restored=new DatabaseSync(process.argv[4]);try{restored.exec('DELETE FROM sessions; DELETE FROM tokens; DELETE FROM mail;');}finally{restored.close();}
  console.log('Restored into a new file; integrity check passed. Restored sessions, recovery links and queued mail revoked. Reconcile deletion requests before reopening access.');
}else{
  if(!BACKUP_DIR)throw Error('BACKUP_DIR required');const store=openStore(DB_FILE,DATA_KEY);
  try{await encryptedBackup(store,path.join(BACKUP_DIR,`mz-${Date.now()}.enc`),BACKUP_KEY);console.log('Encrypted backup saved.');}finally{store.db.close();}
}
