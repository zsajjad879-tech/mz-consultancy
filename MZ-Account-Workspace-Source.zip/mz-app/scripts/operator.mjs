// Local server operator only. There is deliberately no public administrator endpoint.
import fs from 'node:fs';
import {openStore} from '../store.mjs';
const s=openStore(process.env.DB_FILE,process.env.DATA_KEY);
const [command,id,file]=process.argv.slice(2);
try {
  if(command==='leads')console.log(JSON.stringify(s.all('SELECT * FROM leads ORDER BY created DESC LIMIT 100').map(r=>({id:r.id,...s.crypt.open(r.payload,'lead:'+r.id)})),null,2));
  else if(command==='support')console.log(JSON.stringify(s.all('SELECT * FROM records WHERE kind=?','support').map(r=>({account:r.user_id,...s.get(r.user_id,r.id,'support')})),null,2));
  else if(command==='reply'&&id&&file){
    const r=s.one('SELECT * FROM records WHERE kind=? AND id=?','support',id);if(!r)throw Error('Ticket not found');
    const answer=fs.readFileSync(file,'utf8').trim();if(!answer||answer.length>3000)throw Error('Reply must contain 1–3000 characters');
    const ticket=s.get(r.user_id,r.id,'support');s.put(r.user_id,r.id,'support',{...ticket,answer,status:'answered',answeredAt:Date.now()},r.revision+1);s.audit(r.user_id,'support.answered');console.log('Reply saved in the customer workspace. No email sent.');
  }else if(command==='status')console.log(JSON.stringify({accounts:s.one('SELECT count(*) AS n FROM users').n,verified:s.one('SELECT count(*) AS n FROM users WHERE verified=1').n,mailQueued:s.one('SELECT count(*) AS n FROM mail').n,mailFailed:s.one('SELECT count(*) AS n FROM mail WHERE attempts>0').n},null,2));
  else throw Error('Usage: operator.mjs leads | support | status | reply TICKET_ID REPLY_TEXT_FILE. Handle outputs as private customer information.');
}finally{s.db.close();}
