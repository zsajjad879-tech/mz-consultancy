// Stop the server and back up first. Keep old keys for retained backups.
import {openStore,rotateDataKey} from '../store.mjs';
const {DB_FILE,DATA_KEY,NEW_DATA_KEY}=process.env;
if(DATA_KEY===NEW_DATA_KEY)throw Error('New key must be different.');
const store=openStore(DB_FILE,DATA_KEY);
try{rotateDataKey(store,NEW_DATA_KEY);console.log('Key rotation complete. Set DATA_KEY to the new secret before restarting. Sessions and recovery links revoked.');}finally{store.db.close();}
