// Read-only connection check. No connection string or credentials are printed.
const {DATABASE_URL}=process.env;
if(!DATABASE_URL)throw Error('Configure DATABASE_URL privately before running.');
const u=new URL(DATABASE_URL);
if(!u.hostname.endsWith('.neon.tech'))throw Error('Unexpected database host.');
const {default:pg}=await import('pg');
const pool=new pg.Pool({host:u.hostname,port:Number(u.port||5432),database:decodeURIComponent(u.pathname.slice(1)),user:decodeURIComponent(u.username),password:decodeURIComponent(u.password),ssl:{rejectUnauthorized:true},max:1,connectionTimeoutMillis:10000});
try {
  const tls=await pool.query('SELECT ssl FROM pg_stat_ssl WHERE pid=pg_backend_pid()');
  if(tls.rows[0]?.ssl!==true)throw Error('TLS connection required.');
  const result=await pool.query("SELECT table_name FROM information_schema.tables WHERE table_schema='public' ORDER BY table_name");
  const expected=['events','leads','limits','mail','meta','records','sessions','tokens','users'];
  for(const name of expected)if(!result.rows.some(r=>r.table_name===name))throw Error('Missing application table: '+name);
  console.log('PASS: authenticated TLS connection and all 9 application tables verified. No customer records read or written.');
}finally{await pool.end();}
