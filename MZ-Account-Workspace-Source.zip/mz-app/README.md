# MZ Consultancy customer workspace

This is the local, tested account-based MVP. It has not been published, independently security assessed or connected to a real mail/payment provider. Use fictional data until production release gates are met.

## Run locally

Node 24 is required. The local SQLite test path uses Node built-ins. Online PostgreSQL uses the pinned pg package and needs npm install on a network-enabled build runner.

```
node scripts/local.mjs
```

Open http://127.0.0.1:8770/workspace. Local credentials, SQLite database, test email outbox and backups live in `work/mz-runtime`, outside this source directory. Registration writes a verification message to that local outbox; it does not send email. Only the local operator can inspect it. No test-outbox HTTP endpoint exists. Do not upload the runtime folder.

## Verify

```
node test/integration.mjs
npm run check
```

The integration suite creates fictional accounts and removes its temporary test directory after finishing. It covers email verification, reset, two-step authentication, isolation, stale approvals, optimistic concurrency, backups and restore. It is not a substitute for independent assessment.

## Included

- Signup with verified email, scrypt password hashing, TOTP MFA and hashed single-use recovery codes.
- HttpOnly sessions, production Secure cookie, strict same-site policy, origin and CSRF checks, session expiry/revocation, reauthentication for export/deletion/session revocation.
- Each account owns its own invoices. The current role is solo owner: no staff invitations, delegated support access or shared team workspaces.
- AES-256-GCM encrypted profile, invoice, draft, support and lead fields, bound to each account/record. Emails are searched by keyed hash.
- Validated CSV preview/commit, integer-cent calculations, held invoices, payment promises/disputes, revision checks, draft approval invalidation and report export.
- Profile, local support tickets/operator replies, feedback, activity polling, inquiry capture, account export/deletion.
- Encrypted snapshot backup tooling with a separate key; daily backups while the process runs; 30-day snapshot expiry.
- Response CSP, anti-framing, no-sniff, HSTS in production, limited request bodies and durable rate-limit counters.

## Deliberately unavailable until separately implemented and configured

Passkeys, multi-user RBAC, card payments, subscriptions, coupons, accounting sync, automatic reminder sending, AI model calls, n8n and enterprise monitoring. Billing is an honest empty state, not a fake checkout. The assistant's connected Gmail does not provide server credentials. Gmail support would require a secure OAuth/SMTP integration and provider setup; the implemented adapter currently supports Resend only. Domain verification and private API-key configuration are still needed for real email.

## Production gate

Use a Render **Web Service**, not the pending Static Site form. Serve public pages and the app from this one service. Build: `npm run check`; start: `node server.mjs`; health: `/healthz`; Node: 24.

The service refuses production startup without HTTPS origin, durable-storage acknowledgement, encryption keys, backup configuration and email configuration. An environment flag is only an acknowledgement: the operator must actually provision and verify durable storage and exercise restore before launch. The code does not verify the provider's disk provisioning or sending-domain status automatically.

Render free service disks are ephemeral. Free Render Postgres expires after 30 days and is not an indefinite production storage solution. This version uses SQLite and therefore requires an approved persistent disk or a database adapter rewrite. No paid resource has been provisioned. Do not deploy this on free ephemeral storage with real records.

## Operations

`scripts/operator.mjs` is a local server-operator CLI for leads, support replies and mail queue counts. No public administrator API exists. Protect host access with MFA and least privilege; CLI output contains private data.

`scripts/backup.mjs` creates encrypted snapshots; `restore` writes to a new database only. Preserve DATA_KEY and BACKUP_KEY separately from backups. Run restores in isolation and revoke restored sessions/tokens. Reapply deletion requests before restoring user access. A same-disk snapshot is not disaster recovery; configure an approved off-host encrypted copy and monitor job success.

`scripts/rotate-key.mjs` rotates application encryption offline in one transaction. Back up first, stop the server, privately provide DATA_KEY and NEW_DATA_KEY, run it, then replace DATA_KEY before restart. Retain old keys only as needed to read retained backups. Never paste keys into chat, logs or source.

No WAF, independent penetration test, malware scanner, SIEM, multi-region redundancy or compliance certification is claimed. Request limits and local activity records provide limited defenses, not those enterprise services.

## Neon migration update � 9 October 2026

The nine tables were created and verified in Neon project MZ CONSULTANCY, neondb, on its Free plan. The async PostgreSQL adapter and server conversion are implemented. The 16 account/backend integration groups still pass against local SQLite, and five adapter groups pass (PostgreSQL tests use a mocked driver). This is not a live database connection test.

Provide DATABASE_URL privately to the server only. The adapter accepts Neon hosts, keeps TLS certificate validation enabled, uses bound parameters, and pins transaction work to one pool connection. Do not run multiple app instances: read/check/write workflow sequences currently use a bounded process-local queue. A scaling release must replace that with database-level concurrency controls.

Production still fails closed without verified mail and external PostgreSQL backup/restore acknowledgement. REMOTE_BACKUPS_CONFIRMED is not evidence by itself; actual recovery verification is required. SQLite backup/rotation scripts are for local SQLite only, not PostgreSQL.
