import crypto from 'node:crypto';
import {promisify} from 'node:util';
const scrypt = promisify(crypto.scrypt);
export const random = () => crypto.randomBytes(32).toString('base64url');
export const sha = value => crypto.createHash('sha256').update(value).digest('hex');
export function safeEqual(a,b) {
  const x=Buffer.from(String(a)),y=Buffer.from(String(b));
  return x.length===y.length && crypto.timingSafeEqual(x,y);
}
let busy=0;
export async function passwordHash(password,salt=crypto.randomBytes(16).toString('hex')) {
  if(typeof password!=='string'||password.length<12||password.length>128)throw Object.assign(Error('Use a password of 12–128 characters.'),{status:400});
  if(busy>=2)throw Object.assign(Error('Please retry in a moment.'),{status:429});
  busy++;
  try {const key=await scrypt(password,salt,32,{N:131072,r:8,p:1,maxmem:256*1024*1024});return `scrypt$131072$8$1$${salt}$${key.toString('hex')}`;}finally{busy--;}
}
export async function verifyPassword(password,stored) {
  if(typeof password!=='string'||password.length<12||password.length>128)return false;
  const parts=stored.split('$');
  return safeEqual(await passwordHash(password,parts[4]),stored);
}
export function cipher(keyText) {
  if(!/^[a-f0-9]{64}$/i.test(keyText||''))throw Error('Encryption key must be 32 random bytes encoded as hex.');
  const key=Buffer.from(keyText,'hex');
  return {
    index: text=>crypto.createHmac('sha256',key).update(text).digest('hex'),
    seal(value,context) {
      const iv=crypto.randomBytes(12),c=crypto.createCipheriv('aes-256-gcm',key,iv);c.setAAD(Buffer.from(context));
      const data=Buffer.concat([c.update(JSON.stringify(value),'utf8'),c.final()]);
      return [iv,c.getAuthTag(),data].map(x=>x.toString('base64')).join('.');
    },
    open(text,context) {
      const [iv,tag,data]=text.split('.').map(x=>Buffer.from(x,'base64'));
      const d=crypto.createDecipheriv('aes-256-gcm',key,iv);d.setAAD(Buffer.from(context));d.setAuthTag(tag);
      return JSON.parse(Buffer.concat([d.update(data),d.final()]).toString('utf8'));
    }
  };
}
const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
export function base32(bytes) {let bits=0,value=0,out='';for(const byte of bytes){value=(value<<8)|byte;bits+=8;while(bits>=5){out+=alphabet[(value>>>(bits-5))&31];bits-=5;}}if(bits)out+=alphabet[(value<<(5-bits))&31];return out;}
function unbase32(s){let bits=0,value=0,out=[];for(const c of s){const n=alphabet.indexOf(c);if(n<0)throw Error('Invalid secret');value=(value<<5)|n;bits+=5;if(bits>=8){out.push((value>>>(bits-8))&255);bits-=8;}}return Buffer.from(out);}
export function totp(secret,step=Math.floor(Date.now()/30000)) {
  const b=Buffer.alloc(8);b.writeBigUInt64BE(BigInt(step));const digest=crypto.createHmac('sha1',unbase32(secret)).update(b).digest();const o=digest[19]&15;
  return String((digest.readUInt32BE(o)&0x7fffffff)%1000000).padStart(6,'0');
}
export function totpStep(secret,code,last=-1) {
  if(!/^\d{6}$/.test(String(code)))return null;
  const now=Math.floor(Date.now()/30000);
  for(const step of [now,now-1,now+1])if(step>last&&safeEqual(totp(secret,step),code))return step;
  return null;
}
