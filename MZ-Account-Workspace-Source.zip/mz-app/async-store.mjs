import {AsyncLocalStorage} from 'node:async_hooks';
import {openStore} from './store.mjs';
import {cipher} from './security.mjs';

// One pilot process: serialize SQLite operations, including async transactions.
export function mutex(maxPending=100) {
  let tail=Promise.resolve(),pending=0;
  return async fn=>{
    if(pending>=maxPending)throw Object.assign(Error('Service is busy. Please retry shortly.'),{status:503});
    pending++;let release;const previous=tail;tail=new Promise(r=>release=r);
    await previous;try{return await fn();}finally{pending--;release();}
  };
}
export function parameterSQL(sql) {
  // SQL strings are developer-controlled, not user input. Preserve quoted literals.
  let n=0,out='',quoted=false;
  for(let i=0;i<sql.length;i++){
    const c=sql[i];
    if(c==="'"){out+=c;if(quoted&&sql[i+1]==="'"){out+=sql[++i];continue;}quoted=!quoted;}
    else out+=c==='?'&&!quoted?'$'+(++n):c;
  }
  return out;
}
export async function openAsyncStore(cfg) {
  if(!cfg.databaseUrl) {
    const raw=openStore(cfg.dbFile,cfg.key),serial=mutex(),context=new AsyncLocalStorage();
    const wrapped={...raw,kind:'sqlite'};
    for(const name of ['run','one','all','put','get','list','audit'])wrapped[name]=async(...args)=>context.getStore()?raw[name](...args):serial(()=>raw[name](...args));
    wrapped.transaction=async fn=>context.getStore()?fn():serial(async()=>{raw.db.exec('BEGIN IMMEDIATE');try{const value=await context.run(true,fn);raw.db.exec('COMMIT');return value;}catch(e){raw.db.exec('ROLLBACK');throw e;}});
    wrapped.close=()=>raw.db.close();return wrapped;
  }
  const u=new URL(cfg.databaseUrl);
  if(!['postgres:','postgresql:'].includes(u.protocol)||!u.hostname.endsWith('.neon.tech'))throw Error('This deployment only accepts the approved Neon database host.');
  const pg=cfg.driver||(await import('pg')).default;
  // Parse separately: URL sslmode options must not weaken certificate validation.
  const pool=new pg.Pool({host:u.hostname,port:Number(u.port||5432),database:decodeURIComponent(u.pathname.slice(1)),user:decodeURIComponent(u.username),password:decodeURIComponent(u.password),ssl:{rejectUnauthorized:true},max:3,connectionTimeoutMillis:10000,idleTimeoutMillis:10000,statement_timeout:15000});
  pool.on('error',()=>console.error('Database connection error. No credentials logged.'));
  const context=new AsyncLocalStorage(),crypt=cipher(cfg.key);
  const normalize=row=>Object.fromEntries(Object.entries(row).map(([k,v])=>[k,['created','expires','seen','next','until','count','revision','attempts'].includes(k)&&typeof v==='string'&&/^\d+$/.test(v)?Number(v):v]));
  const query=async(sql,args)=>{const r=await(context.getStore()||pool).query(parameterSQL(sql),args);return {...r,rows:r.rows.map(normalize)};};
  const run=async(sql,...args)=>{const r=await query(sql,args);return {changes:r.rowCount};};
  const one=async(sql,...args)=>(await query(sql,args)).rows[0];
  const all=async(sql,...args)=>(await query(sql,args)).rows;
  const transaction=async fn=>{
    if(context.getStore())return fn();const client=await pool.connect();
    try{await client.query('BEGIN');const value=await context.run(client,fn);await client.query('COMMIT');return value;}catch(e){await client.query('ROLLBACK').catch(()=>{});throw e;}finally{client.release();}
  };
  try {
    const marker=await one('SELECT value FROM meta WHERE key=?','keycheck');
    if(marker)crypt.open(marker.value,'keycheck');
    else {await run('INSERT INTO meta VALUES(?,?) ON CONFLICT(key) DO NOTHING','keycheck',crypt.seal('MZ','keycheck'));crypt.open((await one('SELECT value FROM meta WHERE key=?','keycheck')).value,'keycheck');}
  } catch(e){await pool.end();throw e;}
  const put=async(uid,id,kind,payload,revision=1)=>run('INSERT INTO records VALUES(?,?,?,?,?) ON CONFLICT(user_id,id,kind) DO UPDATE SET payload=excluded.payload,revision=excluded.revision',uid,id,kind,crypt.seal(payload,`${uid}:${kind}:${id}`),revision);
  const get=async(uid,id,kind)=>{const r=await one('SELECT * FROM records WHERE user_id=? AND id=? AND kind=?',uid,id,kind);return r?{...crypt.open(r.payload,`${uid}:${kind}:${id}`),revision:r.revision}:null;};
  const list=async(uid,kind)=>(await all('SELECT * FROM records WHERE user_id=? AND kind=? ORDER BY id',uid,kind)).map(r=>({...crypt.open(r.payload,`${uid}:${kind}:${r.id}`),revision:r.revision}));
  const audit=async(uid,kind)=>run('INSERT INTO events(user_id,kind,created) VALUES(?,?,?)',uid,kind,Date.now());
  return {kind:'postgres',crypt,run,one,all,transaction,put,get,list,audit,close:()=>pool.end()};
}
