import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {openAsyncStore,parameterSQL} from '../async-store.mjs';
import {cipher} from '../security.mjs';
const key=crypto.randomBytes(32).toString('hex');
assert.equal(parameterSQL("SELECT '?' AS literal FROM records WHERE id=? AND kind=?"),"SELECT '?' AS literal FROM records WHERE id=$1 AND kind=$2");
assert.equal(parameterSQL("SELECT 'it''s ?' WHERE id=?"),"SELECT 'it''s ?' WHERE id=$1");
console.log('PASS PostgreSQL parameter translation preserves string literals');
const calls=[];let options,released=0;
class Pool {
 constructor(config){options=config;}
 on(){}
 async query(sql,values){calls.push({connection:'pool',sql,values});if(sql.startsWith('SELECT value FROM meta'))return {rowCount:1,rows:[{value:cipher(key).seal('MZ','keycheck')}]};return {rowCount:1,rows:[{created:'1791532800000',revision:2}]};}
 async connect(){return {query:async(sql,values)=>{calls.push({connection:'transaction',sql,values});return {rowCount:1,rows:[]};},release:()=>released++};}
 async end(){}
}
const s=await openAsyncStore({databaseUrl:'postgresql://test:fictional@ep-test.neon.tech/neondb?sslmode=disable',key,driver:{Pool}});
assert.equal(options.ssl.rejectUnauthorized,true);assert.equal(options.max,3);
const row=await s.one('SELECT created,revision FROM records WHERE id=?',"x' OR 1=1 --");assert.equal(row.created,1791532800000);assert.equal(calls.at(-1).sql,'SELECT created,revision FROM records WHERE id=$1');assert.deepEqual(calls.at(-1).values,["x' OR 1=1 --"]);
console.log('PASS TLS certificate validation cannot be disabled through URL; parameters remain bound');
await s.transaction(async()=>{await s.run('UPDATE records SET revision=? WHERE id=?',2,'test');});
assert.deepEqual(calls.slice(-3).map(c=>c.sql),['BEGIN','UPDATE records SET revision=$1 WHERE id=$2','COMMIT']);assert(calls.slice(-3).every(c=>c.connection==='transaction'));
await assert.rejects(s.transaction(async()=>{await s.run('UPDATE records SET revision=?',3);throw Error('rollback');}));assert.equal(calls.at(-1).sql,'ROLLBACK');assert.equal(released,2);await s.close();
console.log('PASS PostgreSQL adapter transactions pin/release one connection and roll back failures (mock driver)');
await assert.rejects(openAsyncStore({databaseUrl:'postgresql://a:b@attacker.example/x',key,driver:{Pool}}));
console.log('PASS Unexpected database hosts rejected');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'mz-async-'));
try {
 const db=await openAsyncStore({dbFile:path.join(dir,'test.sqlite'),key});
 let inside,release;const started=new Promise(r=>inside=r),pause=new Promise(r=>release=r);
 const writing=db.transaction(async()=>{await db.run('INSERT INTO meta VALUES(?,?)','temporary','uncommitted');inside();await pause;throw Error('cancel transaction');});
 await started;let finished=false;const reader=db.one('SELECT value FROM meta WHERE key=?','temporary').then(v=>{finished=true;return v;});
 await new Promise(r=>setTimeout(r,10));assert.equal(finished,false);release();await assert.rejects(writing);assert.equal(await reader,undefined);await db.close();
 console.log('PASS Async SQLite transaction isolates concurrent readers and rollback');
}finally{assert(path.resolve(dir).startsWith(path.resolve(os.tmpdir())+path.sep+'mz-async-'));fs.rmSync(dir,{recursive:true,force:true});}
console.log('5 storage adapter groups passed; live Neon driver connection is not tested by mocks.');
