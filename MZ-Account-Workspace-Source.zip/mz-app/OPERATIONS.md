# Operations and release gates

Owner: MZ Consultancy. Production has not been launched. This runbook is a plan, not proof that external services are active.

## Launch prerequisites

1. Approve durable storage and its recurring cost or select an external managed database and implement/test its adapter. The user's current authorization is free hosting only, so no paid resources have been created.
2. Configure a real transactional mail connection. Existing Gmail connector access is not an application credential. The current app has a Resend adapter; it needs a verified sending domain and a private API key. Gmail OAuth/SMTP is not yet implemented or configured.
3. Verify HTTPS redirect, secure cookies, CSP and availability on the actual Render hostname. Run the complete account/reset/MFA/import/approval flow using staging test accounts first.
4. Test a restore on independent storage. Review the deletion ledger and revoke all restored sessions/tokens/mail before opening access. Keep encryption keys in a separate protected secret store.
5. Review privacy terms, vendor contracts, permitted customer locations, business delivery capability and the data-processing agreement before accepting real records.
6. Commission an independent security review before claiming enterprise readiness or completing requirement 120. No certification or penetration test has occurred.

## Daily

- Inspect provider incidents, process health, failed mail queue entries and backup timestamps. Assign a human owner before launch; no automatic alert destination is connected.
- Review new inquiries and support tickets with the private operator CLI. Reply inside the workspace, or use an explicitly approved support channel. No automated debt reminders are sent.
- Check unhandled application errors without logging passwords, OTPs, tokens, invoice bodies or mail content.
- Transfer encrypted backups to separately approved storage. Daily local snapshots alone will not survive loss of the hosting volume.

## Incident response

Suspected account compromise: disable access to the affected account at the operator level, revoke sessions and tokens, preserve minimal relevant logs, contact the verified account owner, and investigate. Never accept a new email address supplied only by a claimant as identity proof.

Key exposure: place service in maintenance, stop application writes, snapshot safely, rotate affected keys using the offline rotation script, revoke sessions and links, investigate provider access, and communicate confirmed impacts under applicable obligations. A key leak affecting old backups requires separate review; rotation does not undo past disclosure.

Bad import: preserve the source export, review revision changes and reimport verified records. No automated payment reversal or debt escalation exists.

Data loss: restore into a new file, run integrity checks and application tests, reconcile post-snapshot payments and deletion requests, then reopen. Never replace a live file blindly. `backup.mjs restore` refuses to overwrite an existing database.

## Recovery objectives

Proposed pilot target: RPO 24 hours, RTO one business day. These are operational targets, not contractual guarantees or achieved service levels. Daily job execution, off-host storage and restore ownership must be established first. No point-in-time recovery or multi-region failover exists.

## Security boundaries and known limitations

- Single-process SQLite pilot; no horizontal scaling. Host-level disk permissions and encryption must also be verified. Some operational metadata is not field-encrypted.
- Rate limits use socket address plus account keys. Behind a proxy the socket limit may group multiple visitors; do not blindly trust user-supplied forwarded headers. Configure a trusted proxy identity strategy before scaling.
- Event logs are tenant-visible application records; a server/database administrator can alter them. They are not an immutable forensic ledger or SIEM.
- Password-based signup has no CAPTCHA/provider anti-bot integration; limits reduce abuse but do not eliminate it. MFA protects enrolled accounts; production requires enrollment before invoice work.
- Only CSV text is accepted for invoice ingestion, parsed and validated without saving executable files. No general file-upload service or antivirus scanner exists.
- Application field encryption protects a copied database when the key is not available. It does not isolate records from the server operator.
- Passkeys, staff roles, restricted API keys, public third-party APIs and account recovery after losing both authenticator and recovery codes are not implemented. There is no support override that silently disables MFA.
- No actual customer payment processing, AI calls, email marketing, n8n instance, WAF, IDS or off-host alerting is connected.

## Sources checked 9 October 2026

- Render free-service limitations: https://render.com/docs/free
- Render web services and TLS behavior: https://render.com/docs/web-services
- Render persistent disks: https://render.com/docs/disks
- Resend send endpoint: https://resend.com/docs/api-reference/emails/send-email
- Node built-in crypto and SQLite: https://nodejs.org/api/crypto.html and https://nodejs.org/api/sqlite.html
