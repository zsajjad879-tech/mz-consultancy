import {DatabaseSync,backup} from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import {cipher} from './security.mjs';
export function openStore(file,key) {
  fs.mkdirSync(path.dirname(file),{recursive:true});
  const db=new DatabaseSync(file);db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
  CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email_index TEXT UNIQUE NOT NULL,password TEXT NOT NULL,profile TEXT NOT NULL,verified INTEGER NOT NULL DEFAULT 0,mfa TEXT,created INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS sessions(hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,csrf TEXT NOT NULL,scope TEXT NOT NULL,expires INTEGER NOT NULL,seen INTEGER NOT NULL,created INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS tokens(hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,kind TEXT NOT NULL,expires INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS records(user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,id TEXT NOT NULL,kind TEXT NOT NULL,payload TEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 1,PRIMARY KEY(user_id,id,kind));
  CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,kind TEXT NOT NULL,created INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS limits(key TEXT PRIMARY KEY,count INTEGER NOT NULL,until INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS mail(id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,payload TEXT NOT NULL,created INTEGER NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,next INTEGER NOT NULL DEFAULT 0);
  CREATE TABLE IF NOT EXISTS leads(id TEXT PRIMARY KEY,payload TEXT NOT NULL,created INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);`);
  const crypt=cipher(key);
  const marker=db.prepare('SELECT value FROM meta WHERE key=?').get('keycheck');
  if(marker)crypt.open(marker.value,'keycheck');else db.prepare('INSERT INTO meta VALUES(?,?)').run('keycheck',crypt.seal('MZ','keycheck'));
  const run=(sql,...args)=>db.prepare(sql).run(...args),one=(sql,...args)=>db.prepare(sql).get(...args),all=(sql,...args)=>db.prepare(sql).all(...args);
  function transaction(fn){db.exec('BEGIN IMMEDIATE');try{const out=fn();db.exec('COMMIT');return out;}catch(e){db.exec('ROLLBACK');throw e;}}
  function put(uid,id,kind,payload,revision=1){run('INSERT INTO records VALUES(?,?,?,?,?) ON CONFLICT(user_id,id,kind) DO UPDATE SET payload=excluded.payload,revision=excluded.revision',uid,id,kind,crypt.seal(payload,`${uid}:${kind}:${id}`),revision);}
  function get(uid,id,kind){const r=one('SELECT * FROM records WHERE user_id=? AND id=? AND kind=?',uid,id,kind);return r?{...crypt.open(r.payload,`${uid}:${kind}:${id}`),revision:r.revision}:null;}
  function list(uid,kind){return all('SELECT * FROM records WHERE user_id=? AND kind=?',uid,kind).map(r=>({...crypt.open(r.payload,`${uid}:${kind}:${r.id}`),revision:r.revision}));}
  function audit(uid,kind){run('INSERT INTO events(user_id,kind,created) VALUES(?,?,?)',uid,kind,Date.now());}
  return {db,crypt,run,one,all,transaction,put,get,list,audit};
}
export async function encryptedBackup(store,destination,key) {
  fs.mkdirSync(path.dirname(destination),{recursive:true});
  const tmp=destination+'.sqlite';
  try{await backup(store.db,tmp);const data=fs.readFileSync(tmp).toString('base64');fs.writeFileSync(destination,cipher(key).seal({format:1,data},'mz-backup-v1'),{mode:0o600,flag:'wx'});}finally{if(fs.existsSync(tmp))fs.unlinkSync(tmp);}
}
export function restoreBackup(source,destination,key) {
  if(fs.existsSync(destination))throw Error('Restore destination must not exist.');
  const pack=cipher(key).open(fs.readFileSync(source,'utf8'),'mz-backup-v1');if(pack.format!==1)throw Error('Unsupported backup');
  fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,Buffer.from(pack.data,'base64'),{mode:0o600,flag:'wx'});
  const db=new DatabaseSync(destination);try{if(db.prepare('PRAGMA integrity_check').get().integrity_check!=='ok')throw Error('Backup integrity check failed');}finally{db.close();}
}

export function rotateDataKey(s,newKey) {
  const next=cipher(newKey);
  s.transaction(()=>{
  for(const u of s.all('SELECT * FROM users')){
    const profile=s.crypt.open(u.profile,'profile:'+u.id);
    s.run('UPDATE users SET profile=?,email_index=?,mfa=? WHERE id=?',next.seal(profile,'profile:'+u.id),next.index('email:'+profile.email),u.mfa?next.seal(s.crypt.open(u.mfa,'mfa:'+u.id),'mfa:'+u.id):null,u.id);
  }
  for(const r of s.all('SELECT * FROM records')){const context=`${r.user_id}:${r.kind}:${r.id}`;s.run('UPDATE records SET payload=? WHERE user_id=? AND id=? AND kind=?',next.seal(s.crypt.open(r.payload,context),context),r.user_id,r.id,r.kind);}
  for(const r of s.all('SELECT * FROM mail'))s.run('UPDATE mail SET payload=? WHERE id=?',next.seal(s.crypt.open(r.payload,'mail:'+r.id),'mail:'+r.id),r.id);
  for(const r of s.all('SELECT * FROM leads'))s.run('UPDATE leads SET payload=? WHERE id=?',next.seal(s.crypt.open(r.payload,'lead:'+r.id),'lead:'+r.id),r.id);
  s.run('UPDATE meta SET value=? WHERE key=?',next.seal('MZ','keycheck'),'keycheck');s.run('DELETE FROM sessions');s.run('DELETE FROM tokens');s.run('DELETE FROM limits');
});
}
